$(window).on("hashchange", function () {
	if (location.hash.slice(1) == "signup") {
		$(".page").addClass("extend");
		$("#login").removeClass("active");
		$("#signup").addClass("active");
	} else {
		$(".page").removeClass("extend");
		$("#login").addClass("active");
		$("#signup").removeClass("active");
	}
});
$(window).trigger("hashchange");

function validateLoginForm() {
	var name = document.getElementById("logEmail").value;
	var password = document.getElementById("logPassword").value;

	if (mail == "tie@gmail.com" || password == "tie@12345") {
		document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}

	else if (password.length < 8) {
		document.getElementById("errorMsg").innerHTML = "Your password must include atleast 8 characters"
		return false;
	}
	else {
		alert("Successfully signed in");
		return true;
	}
}
function validateSignupForm() {
	var mail = document.getElementById("signEmail").value;
    var password = document.getElementById("signPassword").value;
	var conformPassword = document.getElementById("conformPassword").value;

	if (mail == "tie@gmail.com" || password == "tie@12345"  ) 
	{
		window.location.assign("signup&login.html");
		document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}
    

	else if (password.length < 8) {
		document.getElementById("errorMsg").innerHTML = "Your password must include atleast 8 characters"
		return false;
	}
    else if(password !=conformPassword){
        document.getElementById("errorMsg").innerHTML = "Your password is incorrect"
		return false;
    }
	else {
		alert("Successfully loged in");
		return true;
	}
}
